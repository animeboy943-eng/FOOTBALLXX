import http from "node:http";
import { URL } from "node:url";

const PORT = process.env.PORT || 8080;
const API_KEY = process.env.APISPORTS_KEY;
const API_HOST = "https://v3.football.api-sports.io";

function send(res, code, data) {
  res.writeHead(code, {"content-type":"application/json; charset=utf-8","access-control-allow-origin":"*"});
  res.end(JSON.stringify(data));
}
http.createServer(async (req,res) => {
  const u = new URL(req.url, `http://${req.headers.host}`);
  if (u.pathname === "/api/health") return send(res,200,{ok:true,provider:API_KEY?"api-sports":"not-configured"});
  if (u.pathname === "/api/matches") {
    if (!API_KEY) return send(res,503,{error:"Set APISPORTS_KEY on the server"});
    const date = u.searchParams.get("date") || new Date().toISOString().slice(0,10);
    try {
      const r = await fetch(`${API_HOST}/fixtures?date=${encodeURIComponent(date)}&timezone=Africa%2FTunis`, {
        headers: {"x-apisports-key":API_KEY}
      });
      const body = await r.json();
      if (!r.ok) return send(res,r.status,{error:"Provider request failed",details:body.errors});
      const matches = (body.response || []).map(x => ({
        id:x.fixture?.id, league:x.league?.name, time:x.fixture?.date,
        status:x.fixture?.status?.short, home:x.teams?.home?.name,
        away:x.teams?.away?.name, homeLogo:x.teams?.home?.logo, awayLogo:x.teams?.away?.logo,
        homeGoals:x.goals?.home, awayGoals:x.goals?.away
      }));
      return send(res,200,{date,matches,provider:"API-Sports"});
    } catch(e) { return send(res,502,{error:"Upstream unavailable"}); }
  }
  send(res,404,{error:"Not found"});
}).listen(PORT,()=>console.log(`FOOTBALLX API listening on ${PORT}`));
