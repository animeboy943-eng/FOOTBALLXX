# Build FOOTBALLX V4 APK using only an Android phone

1. Extract this ZIP on your phone.
2. Open https://github.com/ and sign in or create a free account.
3. Create a new repository. Name it `FOOTBALLX-V4`. Choose **Public** for the simplest setup, or use Private if preferred. Do not add a README, license, or .gitignore during repository creation.
4. On the repository page, choose **Add file → Upload files**.
5. Upload the CONTENTS of the `FOOTBALLX-V4` folder, including hidden folder `.github`.
   - Important: the `.github/workflows/android.yml` file must end up at this exact repository path:
     `.github/workflows/android.yml`
   - If your phone's file picker hides `.github`, use GitHub's browser upload page in desktop-site mode, or add `android.yml` manually using **Add file → Create new file** and enter the path `.github/workflows/android.yml`.
6. Commit the upload to the `main` branch.
7. Open the repository's **Actions** tab. Select **Build FOOTBALLX V4 APK**. If prompted, enable workflows. Tap **Run workflow** → **Run workflow**.
8. Wait for the workflow to finish with a green check mark. Open the completed run, scroll to **Artifacts**, and download `FOOTBALLX-V4-debug-APK`.
9. Extract the downloaded artifact ZIP. Inside it is `app-debug.apk`. Tap it to install. If Android asks, allow your browser or Files app to install unknown apps for this installation, then retry.

Notes:
- This creates a debug APK for testing, not a Play Store release.
- The first build can take several minutes.
- The app can show demo fixtures without a live-data backend. Real live fixtures require configuring and hosting the backend and adding a valid API provider key securely on the server. Do not put API keys in the Android app or public repository.
