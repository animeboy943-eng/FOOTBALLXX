# FOOTBALLX V4 — Android VIP starter

A native Kotlin Android application scaffold with a dark navy interface, bilingual labels (English/Arabic toggle), fixtures loading, baseline Poisson-style score estimates, 1X2/Over 2.5/BTTS/double-chance display, and an accuracy-tracking screen.

## Build the APK

Requirements: Android Studio (or JDK 17 + Android SDK + Gradle), Android SDK Platform 35.

1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Output: `app/build/outputs/apk/debug/app-debug.apk`.

This workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The source project is provided.

## Enable live fixtures

Live data needs an API-Sports / API-Football subscription key and a publicly reachable HTTPS backend. Never embed the provider key in the Android APK.

On your server:
```bash
cd backend
export APISPORTS_KEY="YOUR_API_SPORTS_KEY"
export PORT=8080
npm start
```
Deploy behind HTTPS. In the app, open Settings and enter the backend base URL, e.g. `https://api.yourdomain.com`.

The included backend provides:
- `GET /api/health`
- `GET /api/matches?date=YYYY-MM-DD`

## Prediction and accuracy limitations

The included on-device forecast is a transparent demonstration baseline using simple Poisson goal rates. It is not a trained AI model and does not ingest team form, lineups, injuries, xG histories, odds, corners or cards. Corner/card values are placeholders. Do not treat them as betting advice.

For production VIP quality, add a licensed provider for team statistics, injuries, lineups, odds, events and settled results; then train/backtest a model and persist every pre-match prediction with a timestamp. Accuracy metrics should only be calculated after verified final results. The current Accuracy tab explains this rather than inventing a score.
