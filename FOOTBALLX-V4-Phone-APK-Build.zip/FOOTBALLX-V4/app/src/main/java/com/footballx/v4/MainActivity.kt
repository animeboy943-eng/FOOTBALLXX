package com.footballx.v4

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.exp

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 16, 34)
    private val panel = Color.rgb(15, 35, 61)
    private val cyan = Color.rgb(56, 189, 248)
    private val white = Color.WHITE
    private val muted = Color.rgb(163, 184, 207)
    private var arabic = false
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var apiInput: EditText
    private val prefs by lazy { getSharedPreferences("footballx", MODE_PRIVATE) }
    private var matches = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arabic = prefs.getBoolean("arabic", false)
        buildShell()
        loadMatches()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18, 18, 18, 12) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("⚽ FOOTBALLX", 24, cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(button(if (arabic) "EN" else "عربي") { arabic = !arabic; prefs.edit().putBoolean("arabic", arabic).apply(); render() })
        root.addView(header)
        root.addView(label("V4  •  VIP PREDICTION ENGINE", 11, muted, true))
        status = label("Connecting to live data…", 12, muted)
        root.addView(status)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, 12, 0, 12) }
        tabs.addView(button(if (arabic) "المباريات" else "MATCHES") { render() })
        tabs.addView(button(if (arabic) "الدقة" else "ACCURACY") { showAccuracy() })
        tabs.addView(button(if (arabic) "الإعدادات" else "SETTINGS") { showSettings() })
        root.addView(tabs)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadMatches() {
        val base = prefs.getString("api_base", BuildConfig.DEFAULT_API_BASE_URL) ?: BuildConfig.DEFAULT_API_BASE_URL
        status.text = "Loading live fixtures…"
        thread {
            try {
                val date = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val conn = URL(base.trimEnd('/') + "/api/matches?date=" + URLEncoder.encode(date, "UTF-8")).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000; conn.readTimeout = 15000
                val raw = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(raw)
                matches = obj.optJSONArray("matches") ?: JSONArray()
                runOnUiThread { status.text = "LIVE DATA • ${matches.length()} fixtures"; render() }
            } catch (e: Exception) {
                matches = sampleMatches()
                runOnUiThread { status.text = "DEMO MODE • Configure live API server in Settings"; render() }
            }
        }
    }

    private fun sampleMatches() = JSONArray().put(JSONObject().put("home","Arsenal").put("away","Borussia Dortmund").put("league","UEFA Champions League").put("time","21:00")).put(JSONObject().put("home","Manchester City").put("away","Napoli").put("league","UEFA Champions League").put("time","21:00")).put(JSONObject().put("home","Real Madrid").put("away","PSV").put("league","UEFA Champions League").put("time","21:00"))

    private fun render() {
        content.removeAllViews()
        content.addView(label(if (arabic) "توقعات اليوم" else "TODAY'S PREDICTIONS", 20, white, true))
        content.addView(label(if (arabic) "تحليل VIP • مخاطرة متوازنة" else "VIP ANALYSIS • BALANCED RISK", 12, cyan, true))
        for (i in 0 until matches.length()) {
            val m = matches.optJSONObject(i) ?: continue
            val home = m.optString("home", "Home")
            val away = m.optString("away", "Away")
            val pred = predict(home, away)
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(14, 14, 14, 14) }
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 12, 0, 0)
            card.addView(label(m.optString("league", "Football") + "  •  " + m.optString("time", "TBD"), 11, muted, true))
            card.addView(label("$home  vs  $away", 17, white, true))
            card.addView(label("${pred.first}  –  ${pred.second}", 27, cyan, true))
            card.addView(label("1X2  ${pred.home}% / ${pred.draw}% / ${pred.away}%", 13, white))
            card.addView(label("Over 2.5  ${pred.over}%   •   BTTS  ${pred.btts}%", 12, muted))
            card.addView(label("Double chance  ${if (pred.home >= pred.away) "1X" else "X2"}   •   Corners ~9   •   Cards ~4", 12, muted))
            card.addView(label(if (arabic) "توقع إحصائي أولي – ليس ضماناً" else "Baseline statistical estimate – not a guarantee", 10, muted))
            content.addView(card, lp)
        }
        if (matches.length() == 0) content.addView(label("No fixtures returned. Check your data provider.", 14, muted))
        content.addView(button(if (arabic) "تحديث المباريات" else "REFRESH FIXTURES") { loadMatches() })
    }

    data class Forecast(val first:Int,val second:Int,val home:Int,val draw:Int,val away:Int,val over:Int,val btts:Int)
    private fun predict(h:String,a:String): Forecast {
        val seed = (h + a).hashCode()
        val lh = 1.35 + ((seed ushr 2) and 7) / 20.0
        val la = 1.05 + ((seed ushr 5) and 7) / 20.0
        val pH = exp(-lh); val pA = exp(-la)
        fun pois(l:Double,k:Int):Double { var v=exp(-l); for (j in 1..k) v*=l/j; return v }
        var win=0.0; var draw=0.0; var loss=0.0; var over=0.0; var btts=0.0
        for (x in 0..7) for (y in 0..7) {
            val p=pois(lh,x)*pois(la,y)
            if(x>y) win+=p else if(x==y) draw+=p else loss+=p
            if(x+y>2) over+=p
            if(x>0 && y>0) btts+=p
        }
        val scores=(0..5).flatMap { x -> (0..5).map { y -> Triple(x,y,pois(lh,x)*pois(la,y)) } }.maxByOrNull { it.third }!!
        val sum=win+draw+loss
        return Forecast(scores.first,scores.second,(win/sum*100).toInt(),(draw/sum*100).toInt(),(loss/sum*100).toInt(),(over*100).toInt(),(btts*100).toInt())
    }

    private fun showAccuracy() {
        content.removeAllViews()
        content.addView(label(if (arabic) "متابعة الدقة" else "PREDICTION ACCURACY", 21, white, true))
        content.addView(label("No verified results recorded yet.", 14, muted))
        content.addView(label("After each match, enter actual results in the results-tracking backend to calculate 1X2, score, goals and BTTS accuracy.", 13, muted))
        content.addView(label("Accuracy = correct predictions / settled predictions × 100", 12, cyan))
    }

    private fun showSettings() {
        content.removeAllViews()
        content.addView(label(if (arabic) "إعدادات الاتصال" else "LIVE DATA CONNECTION", 20, white, true))
        content.addView(label("Backend API URL (HTTPS)", 13, muted))
        apiInput = EditText(this).apply { setText(prefs.getString("api_base", BuildConfig.DEFAULT_API_BASE_URL)); setTextColor(white); setHintTextColor(muted); setHint("https://your-server.example.com") }
        content.addView(apiInput)
        content.addView(button("SAVE & CONNECT") {
            prefs.edit().putString("api_base", apiInput.text.toString().trim()).apply()
            loadMatches()
        })
        content.addView(label("For security, provider API keys belong on your backend server, never inside the APK.", 12, muted))
    }

    private fun label(s:String,size:Int,color:Int,bold:Boolean=false)=TextView(this).apply {
        text=s; textSize=size.toFloat(); setTextColor(color); if(bold) typeface=Typeface.DEFAULT_BOLD
        setPadding(0,5,0,5)
    }
    private fun button(s:String, action:()->Unit)=Button(this).apply {
        text=s; textSize=11f; setTextColor(white); setBackgroundColor(Color.rgb(22,57,91)); setOnClickListener { action() }
    }
}
